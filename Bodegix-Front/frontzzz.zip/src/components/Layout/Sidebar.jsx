import React from 'react';
import { Drawer, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
import {
    Dashboard as DashboardIcon,
    People as PeopleIcon,
    Lock as LockersIcon,
    Settings as SettingsIcon,
    ExitToApp as LogoutIcon,
    InsertChart as ReportIcon,
    Subscriptions as SubscriptionsIcon,
    PersonAdd as RegisterIcon,
    Visibility as MonitorIcon,
    ShowChart as ChartIcon,
} from '@mui/icons-material';
import Logo from '../common/Logo';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';

const Sidebar = () => {
    const navigate = useNavigate();
    const { user, logout } = React.useContext(AuthContext);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const isAdmin = user?.rol_id === 1 || user?.rol_id === 2;

    const adminMenuItems = [
        { text: 'Dashboard', icon: <DashboardIcon />, path: '/admin/DashboardAdmin' },
        { text: 'Usuarios', icon: <PeopleIcon />, path: '/admin/Users' },
        { text: 'Lockers', icon: <LockersIcon />, path: '/admin/Lockers' },
        { text: 'Reportes', icon: <ReportIcon />, path: '/admin/Reports' },
        { text: 'Suscripciones', icon: <SubscriptionsIcon />, path: '/admin/Suscripciones' },
        { text: 'Registrar Empresa', icon: <RegisterIcon />, path: '/admin/Registro' },
        { text: 'Monitoreo Tiempo Real', icon: <MonitorIcon />, path: '/admin/Monitoreo' },
        { text: 'Gráficas', icon: <ChartIcon />, path: '/admin/Graficas' },
        { text: 'Configuración', icon: <SettingsIcon />, path: '/admin/Settings' },
    ];

    const clienteMenuItems = [
        { text: 'Dashboard', icon: <DashboardIcon />, path: '/cliente/DashboardCliente' },
        { text: 'Monitoreo Tiempo Real', icon: <MonitorIcon />, path: '/cliente/Monitoreo' },
    ];

    const menuItems = isAdmin ? adminMenuItems : clienteMenuItems;

    return (
        <Drawer
            variant="permanent"
            sx={{
                width: 240,
                flexShrink: 0,
                '& .MuiDrawer-paper': {
                    width: 240,
                    boxSizing: 'border-box',
                    backgroundColor: isAdmin ? '#1a2540' : '#37474f',
                    color: '#ffffff',
                },
            }}
        >
            <Logo />
            <List>
                {menuItems.map((item) => (
                    <ListItem button key={item.text} onClick={() => navigate(item.path)}>
                        <ListItemIcon sx={{ color: '#ffffff' }}>
                            {item.icon}
                        </ListItemIcon>
                        <ListItemText primary={item.text} />
                    </ListItem>
                ))}
                <ListItem button onClick={handleLogout}>
                    <ListItemIcon sx={{ color: '#ffffff' }}>
                        <LogoutIcon />
                    </ListItemIcon>
                    <ListItemText primary="Cerrar Sesión" />
                </ListItem>
            </List>
        </Drawer>
    );
};

export default Sidebar;
