import React, { useState, useContext } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import {
    TextField,
    Button,
    Box,
    InputAdornment,
    IconButton,
    Typography,
    Paper
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { login as loginService } from '../../services/authService';

const LoginForm = () => {
    const [showPassword, setShowPassword] = useState(false);
    const [loginError, setLoginError] = useState('');
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();

    const formik = useFormik({
        initialValues: {
            correo: '',
            contraseña: '',
        },
        validationSchema: Yup.object({
            correo: Yup.string().email('Email inválido').required('Requerido'),
            contraseña: Yup.string().required('Requerido'),
        }),
        onSubmit: async (values, { setSubmitting }) => {
            setLoginError('');
            try {
                console.log('[LoginForm] Iniciando sesión con:', values);
                const data = await loginService(values.correo, values.contraseña);
                console.log('[LoginForm] Respuesta del backend:', data);
                login(data.usuario, data.token);

                console.log('[LoginForm] Usuario guardado, redirigiendo según rol...');
                setTimeout(() => {
                    if (data.usuario.rol_id === 1) {
                        console.log('[LoginForm] Redirigiendo a /admin/DashboardAdmin');
                        navigate('/admin/DashboardAdmin', { replace: true });
                    } else if (data.usuario.rol_id === 2 || data.usuario.rol_id === 3) {
                        console.log('[LoginForm] Redirigiendo a /cliente/DashboardCliente');
                        navigate('/cliente/DashboardCliente', { replace: true });
                    } else {
                        console.log('[LoginForm] Rol desconocido, redirigiendo a /login');
                        navigate('/login', { replace: true });
                    }
                }, 200);
            } catch (error) {
                console.error('[LoginForm] Error al iniciar sesión:', error);
                setLoginError('Credenciales incorrectas o error de conexión');
            } finally {
                setSubmitting(false);
            }
        },
    });

    return (
        <Paper elevation={0} sx={{ p: 0, background: 'transparent' }}>
            <form onSubmit={formik.handleSubmit}>
                <Box mb={3}>
                    <TextField
                        fullWidth
                        id="correo"
                        name="correo"
                        label="Email"
                        variant="outlined"
                        value={formik.values.correo}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        error={formik.touched.correo && Boolean(formik.errors.correo)}
                        helperText={formik.touched.correo && formik.errors.correo}
                    />
                </Box>
                <Box mb={3}>
                    <TextField
                        fullWidth
                        id="contraseña"
                        name="contraseña"
                        label="Contraseña"
                        type={showPassword ? 'text' : 'password'}
                        variant="outlined"
                        value={formik.values.contraseña}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        error={formik.touched.contraseña && Boolean(formik.errors.contraseña)}
                        helperText={formik.touched.contraseña && formik.errors.contraseña}
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        onClick={() => setShowPassword(!showPassword)}
                                        edge="end"
                                    >
                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }}
                    />
                </Box>
                {loginError && (
                    <Typography color="error" align="center" mb={2}>
                        {loginError}
                    </Typography>
                )}
                <Button
                    fullWidth
                    variant="contained"
                    color="primary"
                    type="submit"
                    size="large"
                    disabled={formik.isSubmitting}
                    sx={{ borderRadius: 2, py: 1.5, fontWeight: 'bold' }}
                >
                    Iniciar Sesión
                </Button>
            </form>
        </Paper>
    );
};

export default LoginForm;
