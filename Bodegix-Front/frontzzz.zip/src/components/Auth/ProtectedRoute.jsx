import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { CircularProgress, Box } from '@mui/material';

const ProtectedRoute = ({ children, rolesAllowed }) => {
    const { user, loading } = useContext(AuthContext);

    console.log('[ProtectedRoute] loading:', loading);
    console.log('[ProtectedRoute] user:', user);
    console.log('[ProtectedRoute] rolesAllowed:', rolesAllowed);

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
                <CircularProgress />
            </Box>
        );
    }

    if (!user) {
        console.log('[ProtectedRoute] Usuario no autenticado, redirigiendo a /login');
        return <Navigate to="/login" replace />;
    }

    if (rolesAllowed && !rolesAllowed.includes(user.rol_id)) {
        console.log('[ProtectedRoute] Usuario sin permisos, redirigiendo a /login');
        return <Navigate to="/login" replace />;
    }

    console.log('[ProtectedRoute] Usuario autorizado, renderizando children');
    return children;
};

export default ProtectedRoute;
