import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { AuthProvider } from './context/AuthContext';

// Pages
import LoginPage from './pages/LoginPage';
import DashboardAdmin from './pages/admin/DashboardAdmin';
import DashboardCliente from './pages/cliente/DashboardCliente';

// Auth
import ProtectedRoute from './components/Auth/ProtectedRoute';

// Styles (manteniendo tu diseño)
import theme from './styles/theme';

function App() {
    return (
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <AuthProvider>
                <BrowserRouter>
                    <Routes>
                        {/* Página de Login */}
                        <Route path="/login" element={<LoginPage />} />

                        {/* Dashboard Admin para superadmin y admin_empresa */}
                        <Route
                            path="/admin/DashboardAdmin"
                            element={
                                <ProtectedRoute rolesAllowed={[1]}>
                                    <DashboardAdmin />
                                </ProtectedRoute>
                            }
                        />

                        {/* Dashboard Cliente */}
                        <Route
                            path="/cliente/DashboardCliente"
                            element={
                                <ProtectedRoute rolesAllowed={[2]}>
                                    <DashboardCliente />
                                </ProtectedRoute>
                            }
                        />

                        {/* Redirección automática a login para rutas desconocidas */}
                        <Route path="*" element={<Navigate to="/login" />} />
                    </Routes>
                </BrowserRouter>
            </AuthProvider>
        </ThemeProvider>
    );
}

export default App;
