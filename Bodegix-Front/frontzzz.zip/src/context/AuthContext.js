import React, { createContext, useState, useEffect } from 'react';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        console.log('[AuthContext] Verificando localStorage...');
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            console.log('[AuthContext] Usuario encontrado en localStorage:', JSON.parse(storedUser));
            setUser(JSON.parse(storedUser));
        } else {
            console.log('[AuthContext] No hay usuario en localStorage');
        }
        setLoading(false);
    }, []);

    const login = (userData, token) => {
        console.log('[AuthContext] Guardando usuario:', userData);
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(userData));
        setUser(userData);
    };

    const logout = () => {
        console.log('[AuthContext] Cerrando sesión');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};
