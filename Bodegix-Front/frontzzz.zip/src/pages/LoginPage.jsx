import React, { useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { Box, Container, Paper, Typography } from '@mui/material';
import Logo from '../components/common/Logo';
import LoginForm from '../components/Auth/LoginForm';

const LoginPage = () => {
    const { user, loading } = useContext(AuthContext);
    const navigate = useNavigate();

    useEffect(() => {
        if (!loading && user) {
            if (user.rol_id === 1 ) {
                navigate('/admin/DashboardAdmin', { replace: true });
            } else if (user.rol_id === 3 || user.rol === 2) {
                navigate('/cliente/DashboardCliente', { replace: true });
            }
        }
    }, [loading, user, navigate]);

    if (loading) return null; 

    return (
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
            <Container maxWidth="xs">
                <Paper elevation={6} sx={{ p: 4, borderRadius: 3, boxShadow: 4, textAlign: 'center' }}>
                    <Logo />
                    <Typography variant="h5" mt={2} mb={2} color="text.primary">
                        Inicio de Sesión
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mb={3}>
                        Ingresa tus credenciales para acceder al sistema de lockers inteligentes.
                    </Typography>
                    <LoginForm />
                </Paper>
            </Container>
        </Box>
    );
};

export default LoginPage;
