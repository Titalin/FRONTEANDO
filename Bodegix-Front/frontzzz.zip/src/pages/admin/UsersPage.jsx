import React from 'react';
import {
    Box,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    TextField,
    Typography,
    Stack,
} from '@mui/material';
import { Add as AddIcon, Search as SearchIcon } from '@mui/icons-material';
import Sidebar from '../../components/Layout/Sidebar';
import Topbar from '../../components/Layout/Topbar';

const UsersPage = () => {
    const users = [
        { id: 1, name: 'Juan Pérez', email: 'juan@example.com', locker: 'A12', status: 'Activo' },
        { id: 2, name: 'María García', email: 'maria@example.com', locker: 'B05', status: 'Activo' },
        { id: 3, name: 'Carlos López', email: 'carlos@example.com', locker: null, status: 'Inactivo' },
    ];

    return (
        <Box display="flex">
            <Sidebar />
            <Box flexGrow={1} p={3}>
                <Topbar />
                <Typography variant="h5" gutterBottom>
                    Administración de Usuarios
                </Typography>
                <Stack direction="row" justifyContent="space-between" mb={2}>
                    <TextField
                        variant="outlined"
                        placeholder="Buscar usuarios..."
                        size="small"
                        InputProps={{
                            startAdornment: <SearchIcon color="action" />,
                        }}
                    />
                    <Button variant="contained" color="primary" startIcon={<AddIcon />}>
                        Nuevo Usuario
                    </Button>
                </Stack>
                <TableContainer component={Paper}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>ID</TableCell>
                                <TableCell>Nombre</TableCell>
                                <TableCell>Email</TableCell>
                                <TableCell>Locker</TableCell>
                                <TableCell>Estado</TableCell>
                                <TableCell>Acciones</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {users.map((user) => (
                                <TableRow key={user.id}>
                                    <TableCell>{user.id}</TableCell>
                                    <TableCell>{user.name}</TableCell>
                                    <TableCell>{user.email}</TableCell>
                                    <TableCell>
                                        {user.locker || (
                                            <Button variant="outlined" size="small" color="secondary">
                                                Asignar
                                            </Button>
                                        )}
                                    </TableCell>
                                    <TableCell>
                                        <Typography
                                            variant="body2"
                                            color={user.status === 'Activo' ? 'success.main' : 'error.main'}
                                        >
                                            {user.status}
                                        </Typography>
                                    </TableCell>
                                    <TableCell>
                                        <Button size="small" variant="text" color="primary">
                                            Editar
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Box>
        </Box>
    );
};

export default UsersPage;
