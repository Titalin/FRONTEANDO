import React from 'react';
import { Box, Typography, Grid, Paper } from '@mui/material';
import Sidebar from '../../components/Layout/Sidebar';
import Topbar from '../../components/Layout/Topbar';
import {
    InsertChart as ReportIcon,
    ShowChart as ChartIcon,
} from '@mui/icons-material';

const DashboardAdmin = () => {
    const stats = [
        { title: 'Reportes Generados', value: '12', icon: <ReportIcon fontSize="large" /> },
        { title: 'Gráficas Activas', value: '5', icon: <ChartIcon fontSize="large" /> },
    ];

    return (
        <Box display="flex" bgcolor="#1a2540" minHeight="100vh"> {/* ✅ Azul oscuro restaurado */}
            <Sidebar />
            <Box flexGrow={1} p={3}>
                <Topbar title="Panel de Administración" />

                <Typography variant="h5" fontWeight="bold" gutterBottom mt={2} color="white">
                    Bienvenido al panel de administración de Bodegix
                </Typography>
                <Typography variant="body1" color="gray" mb={3}>
                    Aquí puedes consultar reportes y visualizar gráficas para el control de lockers y usuarios de tu empresa.
                </Typography>

                <Grid container spacing={3}>
                    {stats.map((stat, index) => (
                        <Grid item xs={12} sm={6} md={3} key={index}>
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 3,
                                    borderRadius: 2,
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    bgcolor: '#ffffff',
                                    height: '100%',
                                }}
                            >
                                <Box mb={1} color={index % 2 === 0 ? 'primary.main' : 'secondary.main'}>
                                    {stat.icon}
                                </Box>
                                <Typography variant="h4" fontWeight="bold" color={index % 2 === 0 ? 'primary.main' : 'secondary.main'}>
                                    {stat.value}
                                </Typography>
                                <Typography variant="subtitle1" color="text.secondary" align="center">
                                    {stat.title}
                                </Typography>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>

                {/* Área para gráficas en el futuro */}
                <Box mt={5}>
                    <Paper
                        sx={{
                            p: 3,
                            minHeight: 200,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            bgcolor: '#ffffff',
                            borderRadius: 2,
                        }}
                    >
                        <Typography variant="body1" color="text.secondary">
                            Aquí se mostrarán gráficas de uso y reportes detallados.
                        </Typography>
                    </Paper>
                </Box>
            </Box>
        </Box>
    );
};

export default DashboardAdmin;
